jQuery(document).ready(function(){
        jQuery('#postcustom-hide').attr('checked','checked');
           jQuery('#postcustom').show();
});
